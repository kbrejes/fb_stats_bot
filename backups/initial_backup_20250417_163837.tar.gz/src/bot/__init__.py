"""
Telegram bot module for the Facebook Ads Telegram Bot.
""" 