"""
Data processing modules for the Facebook Ads Telegram Bot.
""" 