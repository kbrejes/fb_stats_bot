#!/bin/bash

# Скрипт для настройки автоматических бэкапов через cron

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Получаем абсолютный путь к проекту
PROJECT_PATH=$(cd "$(dirname "$0")/.." && pwd)
BACKUP_SCRIPT="$PROJECT_PATH/tools/auto-backup.sh"

# Проверяем, что скрипт для бэкапа существует и исполняемый
if [ ! -x "$BACKUP_SCRIPT" ]; then
    echo -e "${YELLOW}Делаем скрипт бэкапа исполняемым...${NC}"
    chmod +x "$BACKUP_SCRIPT"
fi

# Проверяем наличие cron
if ! command -v crontab &> /dev/null; then
    echo -e "${RED}❌ ОШИБКА: cron не установлен в системе.${NC}"
    echo -e "${YELLOW}Пожалуйста, установите cron для вашей ОС и запустите скрипт снова.${NC}"
    exit 1
fi

# Проверяем существующие задачи cron для этого скрипта
EXISTING_CRON=$(crontab -l 2>/dev/null | grep -F "$BACKUP_SCRIPT" || echo "")

if [ -n "$EXISTING_CRON" ]; then
    echo -e "${YELLOW}У вас уже настроен автоматический бэкап:${NC}"
    echo -e "$EXISTING_CRON"
    
    echo -e "${YELLOW}Хотите изменить расписание? (y/n)${NC}"
    read -p "> " change_schedule
    
    if [ "$change_schedule" != "y" ]; then
        echo -e "${GREEN}✅ Существующее расписание бэкапов сохранено.${NC}"
        exit 0
    fi
    
    # Удаляем существующее расписание
    TEMP_CRON=$(crontab -l 2>/dev/null | grep -v "$BACKUP_SCRIPT")
    echo "$TEMP_CRON" | crontab -
    echo -e "${GREEN}✅ Существующее расписание удалено.${NC}"
fi

# Предлагаем варианты расписания
echo -e "${YELLOW}Выберите частоту автоматических бэкапов:${NC}"
echo -e "1) ${GREEN}Каждый день${NC} (в полночь)"
echo -e "2) ${GREEN}Каждые 3 дня${NC} (в полночь)"
echo -e "3) ${GREEN}Каждую неделю${NC} (воскресенье в полночь)"
echo -e "4) ${GREEN}Собственное расписание${NC}"
read -p "> " schedule_option

# Устанавливаем расписание в зависимости от выбора
case "$schedule_option" in
    1)
        CRON_SCHEDULE="0 0 * * *"
        SCHEDULE_DESC="каждый день в полночь"
        ;;
    2)
        CRON_SCHEDULE="0 0 */3 * *"
        SCHEDULE_DESC="каждые 3 дня в полночь"
        ;;
    3)
        CRON_SCHEDULE="0 0 * * 0"
        SCHEDULE_DESC="каждое воскресенье в полночь"
        ;;
    4)
        echo -e "${YELLOW}Введите расписание в формате cron (мин час день месяц день_недели):${NC}"
        echo -e "${YELLOW}Пример: 0 0 * * * (каждый день в полночь)${NC}"
        read -p "> " CRON_SCHEDULE
        SCHEDULE_DESC="по вашему расписанию"
        ;;
    *)
        echo -e "${RED}❌ Неверный выбор.${NC}"
        exit 1
        ;;
esac

# Добавляем задачу в cron
(crontab -l 2>/dev/null; echo "$CRON_SCHEDULE $BACKUP_SCRIPT > /tmp/fb_ads_backup.log 2>&1") | crontab -

echo -e "${GREEN}✅ Автоматический бэкап настроен: ${SCHEDULE_DESC}${NC}"
echo -e "${YELLOW}Команда cron:${NC} $CRON_SCHEDULE $BACKUP_SCRIPT"
echo -e "${YELLOW}Логи бэкапа будут сохраняться в:${NC} /tmp/fb_ads_backup.log"
echo -e ""
echo -e "${GREEN}Вы можете проверить настройку командой:${NC}"
echo -e "crontab -l | grep backup"
echo -e ""
echo -e "${GREEN}Чтобы запустить бэкап вручную:${NC}"
echo -e "$BACKUP_SCRIPT" 