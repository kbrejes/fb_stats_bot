#!/bin/bash

# Скрипт для предотвращения потери изменений и автосохранения рабочей версии

# Создаем тег с текущей датой и временем
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BRANCH_NAME=$(git rev-parse --abbrev-ref HEAD)
TAG_NAME="stable_${BRANCH_NAME}_${TIMESTAMP}"

# Создаем тег для текущего состояния
git tag $TAG_NAME

echo "Создан тег $TAG_NAME для текущего состояния репозитория"
echo "Теперь вы всегда можете вернуться к этой версии с помощью:"
echo "git checkout $TAG_NAME"

# Опционально делаем коммит всех изменений
if [ "$1" == "--commit" ]; then
  git add .
  git commit -m "Автоматическое сохранение состояния $TIMESTAMP"
  echo "Все изменения закоммичены"
fi

# Опционально пушим теги
if [ "$1" == "--push" ] || [ "$2" == "--push" ]; then
  git push origin $TAG_NAME
  echo "Тег отправлен в удаленный репозиторий"
fi 