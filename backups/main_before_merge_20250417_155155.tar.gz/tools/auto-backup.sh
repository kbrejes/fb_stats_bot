#!/bin/bash

# Скрипт для автоматического бэкапа проекта
# Рекомендуется запускать по расписанию через cron

# Директория для бэкапов
BACKUP_DIR="backups"
mkdir -p "$BACKUP_DIR"

# Текущая дата и время
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Имя ветки
BRANCH_NAME=$(git rev-parse --abbrev-ref HEAD)

# Сначала создаем тег для текущего состояния
TAG_NAME="auto_backup_${TIMESTAMP}"
git tag "$TAG_NAME"
echo "✅ Создан тег $TAG_NAME"

# Создаем полный бэкап проекта
BACKUP_FILE="${BACKUP_DIR}/fb_ads_tg_bot_backup_${TIMESTAMP}.tar.gz"
tar -czf "$BACKUP_FILE" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
echo "✅ Создан полный бэкап проекта: $BACKUP_FILE"

# Создаем бэкап базы данных, если она существует
DB_FILE="src/db/database.sqlite"
if [ -f "$DB_FILE" ]; then
    DB_BACKUP="${BACKUP_DIR}/database_backup_${TIMESTAMP}.sqlite"
    cp "$DB_FILE" "$DB_BACKUP"
    echo "✅ Создан бэкап базы данных: $DB_BACKUP"
fi

# Проверяем, надо ли удалять старые бэкапы
# По умолчанию оставляем последние 10 бэкапов
MAX_BACKUPS=10
CURRENT_BACKUPS=$(ls -1 ${BACKUP_DIR}/fb_ads_tg_bot_backup_*.tar.gz 2>/dev/null | wc -l)

if [ "$CURRENT_BACKUPS" -gt "$MAX_BACKUPS" ]; then
    # Удаляем самые старые бэкапы
    NUM_TO_DELETE=$((CURRENT_BACKUPS - MAX_BACKUPS))
    echo "🧹 Удаляем $NUM_TO_DELETE устаревших бэкапов..."
    
    ls -1t ${BACKUP_DIR}/fb_ads_tg_bot_backup_*.tar.gz | tail -n $NUM_TO_DELETE | xargs rm -f
    echo "✅ Старые бэкапы удалены"
fi

echo "✅ Бэкап завершен успешно!"
echo "📊 Статистика: сохранено ${CURRENT_BACKUPS} бэкапов." 