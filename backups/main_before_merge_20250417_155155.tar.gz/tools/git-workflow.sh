#!/bin/bash

# Скрипт для правильного порядка работы с Git
# Предотвращает случайные коммиты в main и помогает организовать работу

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функция для создания новой ветки
create_feature_branch() {
    local branch_type=$1
    local branch_name=$2
    
    # Синхронизируемся с main
    echo -e "${YELLOW}Обновляем main из удаленного репозитория...${NC}"
    git checkout main
    git pull
    
    # Создаем новую ветку
    new_branch="${branch_type}/${branch_name}"
    echo -e "${GREEN}Создаем новую ветку: ${new_branch}${NC}"
    git checkout -b "$new_branch"
    
    echo -e "${GREEN}✅ Ветка ${new_branch} создана. Теперь можно вносить изменения.${NC}"
    echo -e "${YELLOW}После завершения работы используйте: ./tools/git-workflow.sh commit${NC}"
}

# Функция для коммита изменений
commit_changes() {
    current_branch=$(git rev-parse --abbrev-ref HEAD)
    
    # Проверяем, что мы не в ветке main
    if [ "$current_branch" == "main" ]; then
        echo -e "${RED}❌ ОШИБКА: Вы пытаетесь внести изменения в ветку main!${NC}"
        echo -e "${YELLOW}Создайте новую ветку: ./tools/git-workflow.sh feature <название-задачи>${NC}"
        exit 1
    fi
    
    # Показываем текущие изменения
    echo -e "${YELLOW}Текущие изменения:${NC}"
    git status -s
    
    # Спрашиваем сообщение коммита
    echo -e "${YELLOW}Введите сообщение коммита:${NC}"
    read -p "> " commit_message
    
    # Создаем полный бэкап перед коммитом
    timestamp=$(date +%Y%m%d_%H%M%S)
    backup_dir="backups"
    mkdir -p "$backup_dir"
    backup_file="${backup_dir}/pre_commit_backup_${timestamp}.tar.gz"
    tar -czf "$backup_file" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
    echo -e "${GREEN}✅ Создан бэкап перед коммитом: ${backup_file}${NC}"
    
    # Коммитим изменения
    git add .
    git commit -m "$commit_message"
    
    # Создаем тег для сохранения
    tag_name="save_${current_branch}_${timestamp}"
    git tag "$tag_name"
    
    echo -e "${GREEN}✅ Изменения сохранены в коммите и теге ${tag_name}${NC}"
    echo -e "${YELLOW}Для завершения работы над задачей используйте: ./tools/git-workflow.sh finish${NC}"
}

# Функция для завершения работы и слияния с main
finish_feature() {
    current_branch=$(git rev-parse --abbrev-ref HEAD)
    
    # Проверяем, что мы не в ветке main
    if [ "$current_branch" == "main" ]; then
        echo -e "${RED}❌ ОШИБКА: Вы уже находитесь в ветке main!${NC}"
        exit 1
    fi
    
    # Создаем финальный бэкап текущей ветки
    timestamp=$(date +%Y%m%d_%H%M%S)
    tag_name="final_${current_branch}_${timestamp}"
    git tag "$tag_name"
    
    # Создаем полный бэкап проекта
    mkdir -p backups
    pre_merge_backup="backups/pre_merge_${current_branch}_${timestamp}.tar.gz"
    tar -czf "$pre_merge_backup" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
    
    echo -e "${GREEN}✅ Создан финальный бэкап ветки в теге ${tag_name} и архиве${NC}"
    
    # Спрашиваем подтверждение для слияния
    echo -e "${YELLOW}Вы уверены, что хотите завершить работу и слить изменения в main? (y/n)${NC}"
    read -p "> " confirmation
    
    if [ "$confirmation" != "y" ]; then
        echo -e "${YELLOW}Операция отменена.${NC}"
        exit 0
    fi
    
    # НОВАЯ ЗАЩИТА: Сначала проверяем, будут ли конфликты при слиянии
    echo -e "${YELLOW}Проверяем возможные конфликты при слиянии...${NC}"
    
    # Сохраняем текущие изменения
    git add .
    git stash save "Автоматическое сохранение перед проверкой слияния"
    
    # Проверяем, можно ли слить без конфликтов
    git checkout main
    can_merge=true
    git merge --no-commit --no-ff "$current_branch" > /dev/null 2>&1 || can_merge=false
    
    # Отменяем пробное слияние
    git merge --abort > /dev/null 2>&1
    
    # Возвращаемся в исходную ветку
    git checkout "$current_branch"
    git stash pop > /dev/null 2>&1
    
    # Если будут конфликты, предупреждаем и предлагаем варианты
    if [ "$can_merge" = false ]; then
        echo -e "${RED}⚠️ ВНИМАНИЕ: При слиянии возможны конфликты!${NC}"
        echo -e "${YELLOW}Рекомендуется один из следующих вариантов:${NC}"
        echo -e "1) ${GREEN}Создать новую ветку из main и перенести изменения${NC}"
        echo -e "2) ${GREEN}Продолжить слияние вручную (требуется разрешение конфликтов)${NC}"
        echo -e "3) ${GREEN}Отменить операцию${NC}"
        read -p "> " conflict_option
        
        case "$conflict_option" in
            1)
                new_branch_name="${current_branch}_new"
                echo -e "${YELLOW}Создаем новую ветку ${new_branch_name} из main...${NC}"
                git checkout main
                git pull
                git checkout -b "$new_branch_name"
                
                # Добавляем предупреждение для пользователя
                echo -e "${GREEN}✅ Создана новая ветка ${new_branch_name}${NC}"
                echo -e "${YELLOW}Теперь вы можете скопировать нужные изменения из ветки ${current_branch}${NC}"
                echo -e "${YELLOW}Используйте: git cherry-pick <commit> или скопируйте файлы вручную${NC}"
                exit 0
                ;;
            2)
                echo -e "${YELLOW}Продолжаем слияние. Будьте готовы разрешить конфликты вручную.${NC}"
                ;;
            *)
                echo -e "${YELLOW}Операция отменена.${NC}"
                exit 0
                ;;
        esac
    fi
    
    # Обновляем main
    git checkout main
    git pull
    
    # Создаем бэкап main перед слиянием
    main_backup="backups/main_before_merge_${timestamp}.tar.gz"
    tar -czf "$main_backup" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
    echo -e "${GREEN}✅ Создан бэкап main перед слиянием: ${main_backup}${NC}"
    
    # Сливаем изменения с защитой
    echo -e "${YELLOW}Сливаем изменения из ${current_branch} в main...${NC}"
    if git merge "$current_branch"; then
        # Успешное слияние
        echo -e "${GREEN}✅ Ветка ${current_branch} успешно слита в main${NC}"
        
        # Создаем бэкап после успешного слияния
        post_merge_backup="backups/post_merge_${current_branch}_${timestamp}.tar.gz"
        tar -czf "$post_merge_backup" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
        echo -e "${GREEN}✅ Создан бэкап после слияния: ${post_merge_backup}${NC}"
        
        # Обновляем рабочую версию
        git tag -f working-version
        echo -e "${GREEN}✅ Тег working-version обновлен${NC}"
    else
        # Слияние не удалось - конфликты
        echo -e "${RED}❌ При слиянии возникли конфликты!${NC}"
        echo -e "${YELLOW}Варианты действий:${NC}"
        echo -e "1) ${GREEN}Разрешить конфликты вручную и продолжить${NC}"
        echo -e "2) ${GREEN}Отменить слияние и вернуться в исходную ветку${NC}"
        echo -e "3) ${GREEN}Восстановить из бэкапа ${main_backup}${NC}"
        read -p "> " merge_conflict_option
        
        case "$merge_conflict_option" in
            1)
                echo -e "${YELLOW}Пожалуйста, разрешите конфликты, затем выполните:${NC}"
                echo -e "${YELLOW}git add . && git commit && git tag -f working-version${NC}"
                exit 0
                ;;
            2)
                git merge --abort
                git checkout "$current_branch"
                echo -e "${YELLOW}Слияние отменено, вы вернулись в ветку ${current_branch}${NC}"
                exit 0
                ;;
            3)
                git merge --abort
                echo -e "${YELLOW}Восстанавливаем из бэкапа ${main_backup}...${NC}"
                # TODO: Добавить код для распаковки бэкапа
                echo -e "${YELLOW}Для восстановления распакуйте архив: ${main_backup}${NC}"
                exit 0
                ;;
            *)
                git merge --abort
                echo -e "${YELLOW}Слияние отменено.${NC}"
                exit 0
                ;;
        esac
    fi
    
    # Предлагаем удалить ветку
    echo -e "${YELLOW}Удалить ветку ${current_branch}? (y/n)${NC}"
    read -p "> " delete_confirmation
    
    if [ "$delete_confirmation" == "y" ]; then
        git branch -d "$current_branch"
        echo -e "${GREEN}✅ Ветка ${current_branch} удалена${NC}"
    fi
}

# Новая функция для проверки истории слияний
check_merge_history() {
    echo -e "${YELLOW}Проверяем историю слияний...${NC}"
    
    # Показываем последние 10 коммитов с информацией о слияниях
    echo -e "${YELLOW}Последние 10 коммитов:${NC}"
    git log --oneline --graph --decorate -n 10
    
    # Показываем последние слияния
    echo -e "\n${YELLOW}Последние слияния:${NC}"
    git log --merges --oneline -n 5
    
    # Проверяем наличие бэкапов перед слиянием
    echo -e "\n${YELLOW}Бэкапы перед слиянием:${NC}"
    ls -lt backups/pre_merge_* 2>/dev/null || echo "Бэкапы перед слиянием не найдены"
    
    echo -e "\n${YELLOW}Бэкапы после слияния:${NC}"
    ls -lt backups/post_merge_* 2>/dev/null || echo "Бэкапы после слияния не найдены"
}

# Новая функция для сравнения веток
compare_branches() {
    branch1=$1
    branch2=$2
    
    if [ -z "$branch1" ] || [ -z "$branch2" ]; then
        echo -e "${YELLOW}Укажите две ветки для сравнения:${NC}"
        git branch
        echo -e "${YELLOW}Ветка 1:${NC}"
        read -p "> " branch1
        echo -e "${YELLOW}Ветка 2:${NC}"
        read -p "> " branch2
    fi
    
    echo -e "${YELLOW}Сравниваем ветки ${branch1} и ${branch2}...${NC}"
    
    # Показываем все различия в файлах
    git diff --name-status "$branch1" "$branch2"
    
    # Показываем разницу в коммитах
    echo -e "\n${YELLOW}Коммиты в ${branch1}, которых нет в ${branch2}:${NC}"
    git log --oneline "$branch2".."$branch1"
    
    echo -e "\n${YELLOW}Коммиты в ${branch2}, которых нет в ${branch1}:${NC}"
    git log --oneline "$branch1".."$branch2"
}

# Функция для восстановления из тега
restore_tag() {
    tag_name=$1
    
    if [ -z "$tag_name" ]; then
        echo -e "${YELLOW}Доступные теги:${NC}"
        git tag -l
        echo -e "${YELLOW}Введите имя тега для восстановления:${NC}"
        read -p "> " tag_name
    fi
    
    # Проверяем существование тега
    if ! git rev-parse "$tag_name" >/dev/null 2>&1; then
        echo -e "${RED}❌ ОШИБКА: Тег ${tag_name} не существует!${NC}"
        exit 1
    fi
    
    # Создаем бэкап текущего состояния
    timestamp=$(date +%Y%m%d_%H%M%S)
    current_branch=$(git rev-parse --abbrev-ref HEAD)
    backup_tag="backup_before_restore_${timestamp}"
    git tag "$backup_tag"
    
    # Также создаем физический бэкап
    mkdir -p backups
    backup_file="backups/backup_before_restore_${timestamp}.tar.gz"
    tar -czf "$backup_file" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
    
    echo -e "${GREEN}✅ Текущее состояние сохранено в теге ${backup_tag} и архиве ${backup_file}${NC}"
    
    # Восстанавливаем из тега
    echo -e "${YELLOW}Восстанавливаем состояние из тега ${tag_name}...${NC}"
    git checkout "$tag_name"
    
    echo -e "${GREEN}✅ Состояние успешно восстановлено из тега ${tag_name}${NC}"
    echo -e "${YELLOW}ВНИМАНИЕ: Вы находитесь в состоянии detached HEAD!${NC}"
    echo -e "${YELLOW}Если хотите продолжить работу, создайте новую ветку:${NC}"
    echo -e "${YELLOW}git checkout -b new_branch_name${NC}"
}

# Новая функция для восстановления из архива
restore_backup() {
    backup_file=$1
    
    if [ -z "$backup_file" ]; then
        echo -e "${YELLOW}Доступные бэкапы:${NC}"
        ls -lt backups/*.tar.gz
        echo -e "${YELLOW}Введите путь к бэкапу для восстановления:${NC}"
        read -p "> " backup_file
    fi
    
    # Проверяем существование бэкапа
    if [ ! -f "$backup_file" ]; then
        echo -e "${RED}❌ ОШИБКА: Файл бэкапа ${backup_file} не найден!${NC}"
        exit 1
    fi
    
    # Создаем бэкап текущего состояния перед восстановлением
    timestamp=$(date +%Y%m%d_%H%M%S)
    backup_before_restore="backups/backup_before_restore_${timestamp}.tar.gz"
    tar -czf "$backup_before_restore" --exclude=".git" --exclude="backups" --exclude="node_modules" --exclude="venv" .
    
    echo -e "${GREEN}✅ Текущее состояние сохранено в архиве ${backup_before_restore}${NC}"
    
    # Спрашиваем подтверждение
    echo -e "${YELLOW}Вы уверены, что хотите восстановить проект из бэкапа ${backup_file}? (y/n)${NC}"
    echo -e "${RED}ВНИМАНИЕ: Это перезапишет текущие файлы!${NC}"
    read -p "> " confirm_restore
    
    if [ "$confirm_restore" != "y" ]; then
        echo -e "${YELLOW}Восстановление отменено.${NC}"
        exit 0
    fi
    
    # Создаем временную директорию для распаковки
    temp_dir=$(mktemp -d)
    
    # Распаковываем бэкап
    echo -e "${YELLOW}Распаковываем бэкап...${NC}"
    tar -xzf "$backup_file" -C "$temp_dir"
    
    # Копируем все файлы из бэкапа, кроме .git
    echo -e "${YELLOW}Восстанавливаем файлы...${NC}"
    rsync -av --exclude='.git' --exclude='backups' "$temp_dir/" ./
    
    # Удаляем временную директорию
    rm -rf "$temp_dir"
    
    echo -e "${GREEN}✅ Проект успешно восстановлен из бэкапа ${backup_file}${NC}"
    echo -e "${YELLOW}Рекомендуется создать новый коммит с восстановленным состоянием:${NC}"
    echo -e "${YELLOW}git add . && git commit -m \"Восстановлено из бэкапа ${backup_file}\"${NC}"
}

# Справка
show_help() {
    echo -e "${GREEN}Система управления Git-рабочим процессом${NC}"
    echo -e "Использование:"
    echo -e "${YELLOW}./tools/git-workflow.sh <команда> [параметры]${NC}"
    echo -e ""
    echo -e "Команды:"
    echo -e "${GREEN}feature <название>${NC} - Создать новую ветку для работы над задачей"
    echo -e "${GREEN}bugfix <название>${NC} - Создать новую ветку для исправления ошибки"
    echo -e "${GREEN}hotfix <название>${NC} - Создать ветку для срочного исправления"
    echo -e "${GREEN}commit${NC} - Сохранить изменения в текущей ветке"
    echo -e "${GREEN}finish${NC} - Завершить работу и слить изменения в main"
    echo -e "${GREEN}restore [тег]${NC} - Восстановить состояние из тега"
    echo -e "${GREEN}restore-backup [файл]${NC} - Восстановить из архивного бэкапа"
    echo -e "${GREEN}tags${NC} - Показать все доступные теги"
    echo -e "${GREEN}check-merges${NC} - Проверить историю слияний"
    echo -e "${GREEN}compare <ветка1> <ветка2>${NC} - Сравнить две ветки"
    echo -e "${GREEN}help${NC} - Показать эту справку"
}

# Показать все теги
show_tags() {
    echo -e "${YELLOW}Все доступные теги в проекте:${NC}"
    git tag -l
}

# Основная логика
case "$1" in
    feature|feat)
        if [ -z "$2" ]; then
            echo -e "${RED}❌ ОШИБКА: Укажите название задачи${NC}"
            echo -e "${YELLOW}Пример: ./tools/git-workflow.sh feature add-new-button${NC}"
            exit 1
        fi
        create_feature_branch "feature" "$2"
        ;;
    bugfix|fix)
        if [ -z "$2" ]; then
            echo -e "${RED}❌ ОШИБКА: Укажите название бага${NC}"
            echo -e "${YELLOW}Пример: ./tools/git-workflow.sh bugfix fix-login-error${NC}"
            exit 1
        fi
        create_feature_branch "bugfix" "$2"
        ;;
    hotfix)
        if [ -z "$2" ]; then
            echo -e "${RED}❌ ОШИБКА: Укажите название hotfix${NC}"
            echo -e "${YELLOW}Пример: ./tools/git-workflow.sh hotfix critical-api-fix${NC}"
            exit 1
        fi
        create_feature_branch "hotfix" "$2"
        ;;
    commit)
        commit_changes
        ;;
    finish)
        finish_feature
        ;;
    restore)
        restore_tag "$2"
        ;;
    restore-backup)
        restore_backup "$2"
        ;;
    tags)
        show_tags
        ;;
    check-merges)
        check_merge_history
        ;;
    compare)
        compare_branches "$2" "$3"
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${RED}❌ Неизвестная команда: $1${NC}"
        show_help
        exit 1
        ;;
esac

exit 0 