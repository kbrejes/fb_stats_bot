#!/bin/bash

# Скрипт для установки всех Git-хуков

# Путь к директории .git/hooks
HOOKS_DIR=".git/hooks"

# Проверяем, что мы находимся в корне Git-репозитория
if [ ! -d "$HOOKS_DIR" ]; then
  echo "❌ Ошибка: директория $HOOKS_DIR не найдена."
  echo "Пожалуйста, запустите этот скрипт из корня репозитория."
  exit 1
fi

# Устанавливаем pre-commit хук
echo "🔧 Устанавливаем pre-commit хук..."
cp tools/pre-commit-hook.sh "$HOOKS_DIR/pre-commit"
chmod +x "$HOOKS_DIR/pre-commit"

# Устанавливаем post-commit хук (опционально можно добавить)
# echo "🔧 Устанавливаем post-commit хук..."
# cp tools/post-commit-hook.sh "$HOOKS_DIR/post-commit"
# chmod +x "$HOOKS_DIR/post-commit"

echo "✅ Git-хуки успешно установлены!"
echo "🛡️ Теперь ваш репозиторий защищен от потери изменений."
echo ""
echo "📋 Дополнительные команды:"
echo "- Ручное создание тега: ./tools/git-save-state.sh"
echo "- Создание тега и коммит: ./tools/git-save-state.sh --commit"
echo "- Создание тега и отправка в удаленный репозиторий: ./tools/git-save-state.sh --push" 