#!/bin/bash

# Git pre-commit hook для автоматической защиты изменений

# Путь к скрипту сохранения состояния относительно корня репозитория
SAVE_SCRIPT="tools/git-save-state.sh"

# Запоминаем текущий статус
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Если мы находимся в main или master ветке, создаем автоматический бэкап
if [ "$CURRENT_BRANCH" == "main" ] || [ "$CURRENT_BRANCH" == "master" ]; then
  echo "🛡️ Обнаружен коммит в ветку $CURRENT_BRANCH. Создаем автоматический бэкап..."
  
  # Создаем тег для текущего состояния
  git tag "auto_backup_${TIMESTAMP}"
  echo "✅ Создан тег auto_backup_${TIMESTAMP}"
  
  # Опционально можно расширить и делать полное резервное копирование
  # например, экспортируя в zip-архив или создавая защищенную ветку
fi

# Запускаем основной скрипт сохранения состояния
if [ -f "$SAVE_SCRIPT" ]; then
  echo "📦 Запускаем скрипт защиты состояния..."
  sh "$SAVE_SCRIPT"
else
  echo "⚠️ Скрипт защиты состояния не найден по пути: $SAVE_SCRIPT"
fi

# Всегда возвращаем 0, чтобы не блокировать коммит
exit 0 