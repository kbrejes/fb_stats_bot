# Facebook Ads Telegram Bot

Телеграм-бот для управления рекламными кампаниями в Facebook.

## Важно! Система защиты от потери кода

Проект использует защищенную систему контроля версий, предотвращающую потерю кода. 

### Перед началом работы:

1. Настройте Git-хуки:
```bash
chmod +x tools/setup-git-hooks.sh
./tools/setup-git-hooks.sh
```

2. Ознакомьтесь с правильным процессом работы:
```
cat docs/GIT-WORKFLOW.md
```

3. Используйте наш инструмент для работы с Git:
```bash
./tools/git-workflow.sh help
```

### Защита от потери кода:

- Все изменения автоматически сохраняются в тегах
- Регулярно создаются полные бэкапы проекта в `/backups`
- Тег `working-version` всегда указывает на последнюю рабочую версию

### Восстановление:

```bash
git checkout working-version
# или
./tools/git-workflow.sh restore
```

## Возможности

- Авторизация в Facebook Ads через OAuth
- Просмотр списка рекламных аккаунтов
- Получение данных о кампаниях и объявлениях
- Выгрузка статистики за выбранный период
- Экспорт данных в CSV, JSON, Excel

## Установка и настройка

1. Клонируйте репозиторий:
```bash
git clone <url> fb_ads_tg_bot
cd fb_ads_tg_bot
```

2. Установите зависимости:
```bash
pip install -r requirements.txt
```

3. Настройте конфигурацию:
```bash
cp .env.example .env
# Отредактируйте файл .env с вашими настройками
```

4. Запустите бота:
```bash
python src/main.py
```

## Функциональность

- Авторизация через Facebook API
- Управление рекламными кампаниями
- Просмотр статистики
- Экспорт данных

## Использование

- `/start` - Начать работу с ботом
- `/auth` - Авторизоваться в Facebook Ads
- `/accounts` - Получить список доступных рекламных аккаунтов
- `/campaigns <account_id>` - Получить список кампаний
- `/ads <campaign_id>` - Получить список объявлений
- `/stats <campaign_id|ad_id> <date_range>` - Получить статистику
- `/export <format>` - Экспортировать данные
- `/help` - Справка по командам

## Требования

- Python 3.10+
- Telegram Bot API Token
- Facebook App с правами на Marketing API

## Лицензия

MIT 

## Environment Setup

The bot supports multiple environments (development and production) to ensure a clear separation between production and local development.

### Environment Files

- `.env.dev` - Development environment configuration
- `.env.prod` - Production environment configuration

### Running in Different Environments

To run the bot in development mode:
```bash
./run_dev.sh
```

To run the bot in production mode:
```bash
./run_prod.sh
```

Alternatively, you can set the environment variable manually:
```bash
export ENVIRONMENT=development  # or production
python main.py
```

### Database Management

Each environment uses its own database:
- Production: `database.sqlite` (or configured PostgreSQL in production)
- Development: `database_dev.sqlite`

To initialize the database using the provided script:
```bash
# For development (default)
python initialize_db.py

# For production
python initialize_db.py --env production
# or
python initialize_db.py -e production
```

To initialize the development database using the shell script:
```bash
./init_dev_db.sh
```

To manually initialize either database:
```bash
# For development
export ENVIRONMENT=development
python -c "from src.storage.database import init_db; init_db()"

# For production
export ENVIRONMENT=production
python -c "from src.storage.database import init_db; init_db()"
```

### Configuration Differences

- Development environment uses a separate database (`database_dev.sqlite`)
- Development has DEBUG mode enabled
- Each environment can have its own Telegram bot token
- Production should have appropriate callback URLs for Facebook API 

## Пример изменения для демонстрации коммита

Это пример изменения файла для демонстрации коммита в Git. 