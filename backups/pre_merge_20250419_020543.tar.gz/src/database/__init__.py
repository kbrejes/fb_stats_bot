"""
Database package for the Facebook Ads Telegram Bot.
""" 