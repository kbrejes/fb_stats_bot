"""
Storage module for the Facebook Ads Telegram Bot.
""" 