"""
Language support for the Telegram bot.
"""
from src.utils.languages.language_manager import get_text, set_language, get_language, SUPPORTED_LANGUAGES, fix_user_id 