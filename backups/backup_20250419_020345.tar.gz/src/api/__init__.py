"""
API interaction modules for the Facebook Ads Telegram Bot.
""" 